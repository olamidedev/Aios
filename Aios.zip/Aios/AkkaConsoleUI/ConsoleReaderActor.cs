﻿using System;
using Akka.Actor;

namespace AkkaConsoleUI
{

    /// <summary>
    /// Actor responsible for reading FROM the console. 
    /// Also responsible for calling <see cref="ActorSystem.Terminate"/>.
    /// </summary>
    class ConsoleReaderActor : UntypedActor
    {
        private IActorRef consoleWriterActor;

        public const string ExitCommand = "exit";
        private IActorRef _consoleWriterActor;
        public ConsoleReaderActor(IActorRef consoleWriterActor)
        {
            this.consoleWriterActor = consoleWriterActor;
        }

        protected override void OnReceive(object message)
        {
            throw new System.NotImplementedException();
        }
    }
}