﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleAppUI
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] week1 = { };
            int[] week2 = { };
            int[] week3 = { };
            int[] week4 = { };

            var day = DateTime.Now.DayOfWeek;
            Console.WriteLine("Day " + day);
            var currentdaynumber = DateTime.Now.Day;
            Console.WriteLine("Day Number " + currentdaynumber);
            //set current month to -1
            var lastmonthsameday = DateTime.Now.AddMonths(-1);
            Console.WriteLine("Last Month Same Day Number " + lastmonthsameday);

            var daydiff = DateTime.Now.Subtract(lastmonthsameday);
            Console.WriteLine("Date Diff from today to last month same day " + daydiff.Days);
            Console.WriteLine("Date Diff from today to last month same day " + daydiff.TotalDays);

            List<string[]> reponse = Program.GetFirstandLastDaysInLastOneMonth(DateTime.Now);
            int weekNo = 1;
            foreach (var res in reponse)
            {
                DateTime datStart = Convert.ToDateTime(res[0].ToString());
                string Month = datStart.ToString("MMM");
                string weekno = GetWeekofTheMonthNumber(datStart);
                Console.WriteLine(Month + " Week " + weekno);
                int count = 0;
                while(count < res.Length)
                {
                    Console.WriteLine("Day " + res[count].ToString());
                    
                    count++;
                }
                Console.WriteLine($"End of the week {weekNo}");
                Console.WriteLine("");
                //Console.WriteLine(res);
                weekNo++;
            }

            Console.ReadLine();
        }

        private static List<string[]> GetDaysInLastOneMonth(DateTime currentdateTime)
        {

           List<string[]> listofweekdays = new List<string[]>();
           //Get one Month from current Date 
           var lastmonthsameday = currentdateTime.AddMonths(-1); // DateTime.Now.AddMonths(-1)
            var daydiff = DateTime.Now.Subtract(lastmonthsameday).Days;
            
            int count = 0;
            while (count < daydiff)
            {
                int subcount = 0;
                string[] week = new string[7];
                while (subcount < 7)
                {
                    
                    week[subcount] = lastmonthsameday.AddDays(count).ToString();                   
                   // Console.WriteLine("Day " + lastmonthsameday.AddDays(count).ToString());                   
                    subcount++;
                    count++;
                }
                //Console.WriteLine("End of the week ");
                //Console.WriteLine("");
                listofweekdays.Add(week);


            }

            return listofweekdays; 

        }

        private static List<string[]> GetFirstandLastDaysInLastOneMonth(DateTime currentdateTime)
        {

            List<string[]> listofweekdays = new List<string[]>();
            //Get one Month from current Date 
            var lastmonthsameday = currentdateTime.AddMonths(-1); // DateTime.Now.AddMonths(-1)
            var daydiff = DateTime.Now.Subtract(lastmonthsameday).Days;

            int count = 0;
            while (count < daydiff)
            {
                int subcount = 0;
                string[] week = new string[2];
                while (subcount < 7)
                {
                    if(subcount == 0)
                    {
                        week[0] = lastmonthsameday.AddDays(count).ToString();
                    }
                    if(subcount == 6)
                    {
                        week[1] = lastmonthsameday.AddDays(count).ToString();
                    }
                   
                    // Console.WriteLine("Day " + lastmonthsameday.AddDays(count).ToString());                   
                    subcount++;
                    count++;
                }
                //Console.WriteLine("End of the week ");
                //Console.WriteLine("");
                listofweekdays.Add(week);


            }

            return listofweekdays;

        }

        private static string GetWeekofTheMonthNumber(DateTime date)
        {
            string MonthNo = "";
            DateTime beginningOfMonth = new DateTime(date.Year, date.Month, 1);

            while (date.Date.AddDays(1).DayOfWeek != CultureInfo.CurrentCulture.DateTimeFormat.FirstDayOfWeek)
                date = date.AddDays(1);

            int MonthNoinInt = (int)Math.Truncate((double)date.Subtract(beginningOfMonth).TotalDays / 7f) + 1;

            return MonthNo = MonthNoinInt.ToString();
        }
    }
}
